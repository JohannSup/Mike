<?php

use LDAP\Result;

    header('Content-Type: application/JSON');
    $metodo = $_SERVER['REQUEST_METHOD'];
    switch($metodo){
        case 'GET': //Consulta
            try{
                $client = new PDO("mysql:host=localhost;dbname=staff", "root", "root");
                $result = $client->query("SELECT * FROM personal;");
                $personal = array();
                while($row = $result->fetch(PDO::FETCH_ASSOC)){
                    $personal[] = $row;

                }
                echo json_encode($personal);
            }catch(PDOException $e){
                echo $e->getMessage();
            }
            break;
        case 'POST': //iNSERCION
            if($_GET['accion'] == 'personal'){
                $jsonData = json_decode(file_get_contents("php://input"));
                try{
                    $conn = new PDO("mysql:host=localhost;dbname=staff", "root", "root");
                }catch(PDOException $e){
                    echo $e -> getMessage();
                }

                $query = $conn-> prepare("INSERT INTO 'personal' SET 'name' = :name, 'surname' = :surname,
                 'lastname' = :lastname, 'salary' = :salary, 'birthday' = :birthday, 'position_id' = :position
                 VALUES ");
                 $query->bindParam(":name",$jsonData->name);
                 $query->bindParam(":surname",$jsonData->surname);
                 $query->bindParam(":lastname",$jsonData->lastname);
                 $query->bindParam(":salary",$jsonData->salary);
                 $query->bindParam(":name",$jsonData->name);
                 $query->bindParam(":name",$jsonData->name);
                 $result = $query->execute();
                 if($result){
                    echo("Personal egistrado correctamente. code $result");
                 }else{
                    echo("Error al registrado correctakente code ");
                 }
            }

            break;
        case 'PUT': //ACTUALIZACION
            if($_GET['accion'] == 'personal'){
                $jsonData = json_decode(file_get_contents("php://input"));
                try{
                    $conn = new PDO("mysql:host=localhost;dbname=staff", "root", "root");
                }catch(PDOException $e){
                    echo $e -> getMessage();
                }

                $query = $conn-> prepare("UPDATE 'personal' SET 'name' = :name, 'surname' = :surname,
                 'lastname' = :lastname, 'salary' = :salary, 'birthday' = :birthday, 'position_id' = :position WHERE 'id' = :id;");
                 $query->bindParam(":name",$jsonData->name);
                 $query->bindParam(":surname",$jsonData->surname);
                 $query->bindParam(":lastname",$jsonData->lastname);
                 $query->bindParam(":salary",$jsonData->salary);
                 $query->bindParam(":name",$jsonData->name);
                 $query->bindParam(":name",$jsonData->name);
                 $result = $query->execute();
                 if($result){
                    echo("Personal egistrado correctamente. code $result");
                 }else{
                    echo("Error al registrado correctakente code ");
                 }
            }
            break;
        case 'DELETE': //ELIMINACION
            if($_GET['accion'] == 'personal'){
                $jsonData = json_decode(file_get_contents("php://input"));
                try{
                    $conn = new PDO("mysql:host=localhost;dbname=staff", "root", "root");
                }catch(PDOException $e){
                    echo $e -> getMessage();
                }
                $query = 'DELETE FROM personal WHERE id = :id';
                $pstm = $conn ->prepare($query);
                $pstm->bindParam(":id",$id);
                $rs = $pstm->execute();
                if($result){

                }else{
                   echo("Error al registrado correctakente code ");
                }
            }
            break;
        default:
            echo 'Metodo no soportado';
    }